namespace ShopperHolic.API.ShopperAPI.Models.Security
{
    public class EncSettings
    {
        public string Key { get; set; }
        public string IV { get; set; }        
    }
}